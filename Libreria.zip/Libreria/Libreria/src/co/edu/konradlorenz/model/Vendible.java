package co.edu.konradlorenz.model;

public interface Vendible {

    public double calcularPrecio();

}
