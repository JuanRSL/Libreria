package co.edu.konradlorenz.model;

public class LibroInvalidoException extends Exception {

    public LibroInvalidoException(String msj) {
        super(msj);
    }
}
