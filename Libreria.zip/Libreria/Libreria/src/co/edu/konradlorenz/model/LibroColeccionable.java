package co.edu.konradlorenz.model;

public class LibroColeccionable extends LibroFisico {

    private String edicion;

    public LibroColeccionable() {

    }

    public LibroColeccionable(String edicion, double pesoKg) {
        super(pesoKg);
        this.edicion = edicion;
    }

    public LibroColeccionable(String edicion, String isbn, String titulo, double precioBase, double pesoKg) {
        super(isbn, titulo, precioBase, pesoKg);
        this.edicion = edicion;
    }

    @Override
    public double calcularPrecio() {
        return precioBase * 1.1;
    }

    @Override
    public String getDescripcion() {
        return String.format("[COLECCIONABLE] %s | Edicion: %s ", super.getResumen(), edicion);
    }
}
