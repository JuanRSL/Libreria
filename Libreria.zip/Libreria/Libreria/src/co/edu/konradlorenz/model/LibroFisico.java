package co.edu.konradlorenz.model;

public class LibroFisico extends Libro {

    private double pesoKg;

    public LibroFisico() {
    }

    public LibroFisico(double pesoKg) {
        this.pesoKg = pesoKg;
    }

    public LibroFisico(String isbn, String titulo, double precioBase, double pesoKg) {
        super(isbn, titulo, precioBase);
        this.pesoKg = pesoKg;
    }

    @Override
    public double calcularPrecio() {
        return precioBase;
    }

    @Override
    public String getDescripcion() {
        return String.format("[LIBRO FISICO] %s | Peso: %.2fkg", super.getResumen(), pesoKg);
    }
}
