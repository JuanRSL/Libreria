
package co.edu.konradlorenz.model;

public abstract class Libro implements Vendible {

    protected String isbn;
    protected String titulo;
    protected double precioBase;
    protected int cantidadDisponible = 1;
    protected int cantidadVendida = 0;

    public Libro() {
    }

    public Libro(String isbn, String titulo, double precioBase) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.precioBase = precioBase;
    }

    public abstract String getDescripcion();

    public void agregarUnidades(int unidades) throws Exception {
        if (unidades <= 0) {
            throw new Exception("Las unidades deben ser mayores a cero.");
        }
        this.cantidadDisponible += unidades;
    }

    public void vender(int cantidad) throws Exception {
        if (cantidad <= 0 || cantidad > cantidadDisponible) {
            throw new Exception("Cantidad no válida para vender.");
        }
        cantidadDisponible -= cantidad;
        cantidadVendida += cantidad;
    }

    public String getResumen() {
        return String.format("ISBN: %s | Título: %s | Precio: $%.2f | Unidades disponibles: %d | Vendidas: %d",
                isbn, titulo, calcularPrecio(), cantidadDisponible, cantidadVendida);
    }
}
