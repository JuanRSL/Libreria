package co.edu.konradlorenz.model;

public  class LibroDigital extends Libro {

    private String formato;
    private double tamañoMB;

    public LibroDigital() {
    }

    public LibroDigital(String formato, double tamañoMB, String isbn, String titulo, double precioBase) {
        super(isbn, titulo, precioBase);
        this.formato = formato;
        this.tamañoMB = tamañoMB;
    }

    @Override
    public double calcularPrecio() {
        return precioBase * 0.9;
    }

    @Override
    public void agregarUnidades(int unidades) throws Exception {
        throw new Exception("No se pueden agregar unidades a libros digitales");
    }

    @Override
    public String getDescripcion() {
        return String.format("[LIBRO DIGITAL] %s | Formato: %s | Tamaño: %.2fMB", super.getResumen(), formato, tamañoMB);
    }
}
