package co.edu.konradlorenz.controlller;

import co.edu.konradlorenz.model.Libro;
import co.edu.konradlorenz.model.LibroColeccionable;
import co.edu.konradlorenz.model.LibroDigital;
import co.edu.konradlorenz.model.LibroFisico;
import co.edu.konradlorenz.model.LibroInvalidoException;
import co.edu.konradlorenz.view.Ventana;

public class Controlador {

    static Libro[] libros = new Libro[0];

    public void run() {
        int opcion = 0;
        do {
            Ventana.menu();
            opcion = Ventana.pedirInt("Seleccione una opcion.");
            try {
                switch (opcion) {
                    case 1:
                        agregarUnLibro();
                        break;
                    case 2:
                        agregarUnidadesAUnLibro();
                        break;
                    case 3:
                        retirarLibro();
                        break;
                    case 4:
                        cambiarPosicion();
                        break;
                    case 5:
                        venderLibro();
                        break;
                    case 6:
                        salir();
                        Ventana.mostrarMensaje("Saliendo del programa");
                        break;
                    default:
                        Ventana.mostrarMensaje("Opcion Invalida");
                }
            } catch (Exception e) {
                Ventana.mostrarMensaje("Error: " + e.getMessage());
            }
        } while (opcion != 6);

    }

    public void agregarUnLibro() {
        try {
            Ventana.mostrarMensaje("Ingreso a la opcion 1: Agregar libro\nSeleccione el tipo de libro:\n1. Libro Fisico\n2. Libro Digital\n3. Libro Coleccionable");
            int tipo = Integer.parseInt(Ventana.pedirString());

            switch (tipo) {
                case 1:
                    Ventana.mostrarMensaje("Ingrese los datos separados por & (isbn&titulo&precio&pesoKg):");
                    String[] datosFisico = Ventana.pedirString().split("&");
                    if (datosFisico.length != 4) {
                        throw new IllegalArgumentException("Debe ingresar 4 datos.");
                    }
                    String isbn = datosFisico[0];
                    String titulo = datosFisico[1];
                    double precio = Double.parseDouble(datosFisico[2].replace(",", ""));
                    double peso = Double.parseDouble(datosFisico[3].replace(",", ""));
                    LibroFisico lf = new LibroFisico(isbn, titulo, precio, peso);
                    agregarLibroAlArreglo(lf);
                    Ventana.mostrarMensaje(lf.toString());
                    break;

                case 2:
                    Ventana.mostrarMensaje("Ingrese los datos separados por & (isbn&titulo&precio&formato&tamanoMB):");
                    String[] datosDigital = Ventana.pedirString().split("&");
                    if (datosDigital.length != 5) {
                        throw new IllegalArgumentException("Debe ingresar 5 datos.");
                    }
                    String isbnD = datosDigital[0];
                    String tituloD = datosDigital[1];
                    double precioD = Double.parseDouble(datosDigital[2].replace(",", ""));
                    String formato = datosDigital[3];
                    double tamano = Double.parseDouble(datosDigital[4].replace(",", ""));
                    LibroDigital ld = new LibroDigital(formato, tamano, isbnD, tituloD, precioD);
                    agregarLibroAlArreglo(ld);
                    Ventana.mostrarMensaje(ld.toString());
                    break;

                case 3:
                    Ventana.mostrarMensaje("Ingrese los datos separados por & (isbn&título&precio&pesoKg&númeroEdición&totalEdiciones):");
                    String[] datosColec = Ventana.pedirString().split("&");
                    if (datosColec.length != 6) {
                        throw new IllegalArgumentException("Debe ingresar 6 datos.");
                    }
                    String isbnC = datosColec[0];
                    String tituloC = datosColec[1];
                    double precioC = Double.parseDouble(datosColec[2].replace(",", ""));
                    double pesoC = Double.parseDouble(datosColec[3].replace(",", ""));
                    String numEd = datosColec[4];
                    LibroColeccionable lc = new LibroColeccionable(numEd, isbnC, tituloC, precioC, pesoC);
                    agregarLibroAlArreglo(lc);
                    Ventana.mostrarMensaje(lc.toString());
                    break;

                default:
                    Ventana.mostrarMensaje("Opción inválida.");
            }

        } catch (NumberFormatException e) {
            Ventana.mostrarMensaje("Error en el formato numérico. Asegúrese de usar punto (.) para decimales y valores válidos.");
        } catch (IllegalArgumentException e) {
            Ventana.mostrarMensaje("Error: " + e.getMessage());
        } catch (Exception e) {
            Ventana.mostrarMensaje("Ocurrió un error inesperado: " + e.getMessage());
        }
    }

    private void agregarLibroAlArreglo(Libro nuevoLibro) {
        Libro[] nuevoArreglo = new Libro[libros.length + 1];
        for (int i = 0; i < libros.length; i++) {
            nuevoArreglo[i] = libros[i];
        }
        nuevoArreglo[libros.length] = nuevoLibro;
        libros = nuevoArreglo;
    }

    public void agregarUnidadesAUnLibro() {
        try {
            Ventana.mostrarMensaje("Ingreso a la opcion 2: Agregar unidades a un libro\nLibros:");

            for (int i = 0; i < libros.length; i++) {
                String mensaje = (libros[i] == null)
                        ? (i + 1) + ". Espacio disponible."
                        : (i + 1) + ". " + libros[i].getResumen();
                Ventana.mostrarMensaje(mensaje);
            }

            Ventana.mostrarMensaje("Ingrese los datos separados por & (libro&unidades):");
            String[] datos = Ventana.pedirString().split("&");

            if (datos.length != 2) {
                throw new LibroInvalidoException("Debe ingresar dos datos separados por &.");
            }

            int indiceLibro = Integer.parseInt(datos[0]) - 1;
            int unidades = Integer.parseInt(datos[1]);

            if (indiceLibro < 0 || indiceLibro >= libros.length || libros[indiceLibro] == null) {
                throw new LibroInvalidoException("El libro seleccionado no existe.");
            }

            if (libros[indiceLibro] instanceof LibroDigital) {
                throw new LibroInvalidoException("No se pueden agregar unidades a un libro digital.");
            }

            libros[indiceLibro].agregarUnidades(unidades);

            Ventana.mostrarMensaje("Se agregaron " + unidades + " unidades al libro " + (indiceLibro + 1) + ":\n"
                    + libros[indiceLibro].getResumen());

        } catch (NumberFormatException e) {
            Ventana.mostrarMensaje("Formato numerico invalido. Asegurese de ingresar solo numeros.");
        } catch (LibroInvalidoException e) {
            Ventana.mostrarMensaje("Error de libro: " + e.getMessage());
        } catch (Exception e) {
            Ventana.mostrarMensaje("Error inesperado: " + e.getMessage());
        }
    }

    public void retirarLibro() {
        try {
            Ventana.mostrarMensaje("Ingreso a la opcion 3: Retirar libro\nLibros:");

            for (int i = 0; i < libros.length; i++) {
                String mensaje;
                if (libros[i] == null) {
                    mensaje = (i + 1) + ". Espacio disponible.";
                } else {
                    mensaje = (i + 1) + ". " + libros[i].getResumen();
                }

            }

            Ventana.mostrarMensaje("Ingrese el número de libro que desea retirar:");
            int indice = Integer.parseInt(Ventana.pedirString()) - 1;

            if (indice < 0 || indice >= libros.length) {
                throw new LibroInvalidoException("Índice fuera de rango.");
            }

            if (libros[indice] == null) {
                throw new LibroInvalidoException("No se puede retirar el libro porque no existe.");
            }

            Ventana.mostrarMensaje("Se retiró el libro " + (indice + 1) + ":\n" + libros[indice].getResumen());
            libros[indice] = null;

        } catch (NumberFormatException e) {
            Ventana.mostrarMensaje("Debe ingresar un número válido.");
        } catch (LibroInvalidoException e) {
            Ventana.mostrarMensaje("Error de libro: " + e.getMessage());
        } catch (Exception e) {
            Ventana.mostrarMensaje("Error inesperado: " + e.getMessage());
        }
    }

    public void cambiarPosicion() {

    }

    public void venderLibro() {

    }

    public void salir() {
        System.exit(0);
    }
}
