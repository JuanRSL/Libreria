
package co.edu.konradlorenz.controlller;

public class AplMain {

    public static void main(String[] args) {
        Controlador c = new Controlador();
        c.run();
    }
    
}
