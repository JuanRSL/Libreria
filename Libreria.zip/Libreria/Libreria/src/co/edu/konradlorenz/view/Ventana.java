/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.konradlorenz.view;

import java.util.Scanner;

public class Ventana {

    static Scanner sc = new Scanner(System.in);

    public static void mostrarMensaje(String s) {
        System.out.println(s);
    }

     public static int pedirInt(String mensaje) {
        System.out.println(mensaje);
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Por favor ingrese un número entero válido.");
            }
        }
    }

    public static double pedirDouble() {
        double a = 0;
        try {
            a = sc.nextDouble();
        } catch (NumberFormatException e) {
            System.out.println(mensaje());
        }
        return a;
    }

    public static String pedirString() {
        return sc.nextLine();
    }

    public static String mensaje() {
        return "";
    }

public static void menu() {
    try {
        mostrarMensaje(
            "MENU:\n" +
            "1. Agregar un libro\n" +
            "2. Agregar unidades a un libro\n" +
            "3. Retirar libro\n" +
            "4. Cambiar libro de posición\n" +
            "5. Vender libro\n" +
            "6. Salir" 
            
        );
    } catch (Exception e) {
        System.out.println("Error al mostrar el menú: " + e.getMessage());
    }
}

}
